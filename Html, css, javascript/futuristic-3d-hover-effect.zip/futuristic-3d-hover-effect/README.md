# Futuristic 3D Hover Effect 🛸

A Pen created on CodePen.io. Original URL: [https://codepen.io/jouanmarcel/pen/NLgVjm](https://codepen.io/jouanmarcel/pen/NLgVjm).

# 🛸
## Usable as navigation, menu or effect
It uses CSS transform and perspective to create a unique hololens-like animation effect.

Can be used for many more use cases, you will probably have your own ideas.

This is an experimental idea, you may want to flesh it out for use in production.