# Fancy Toggle Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/F_Guiffrey/pen/qjamEN](https://codepen.io/F_Guiffrey/pen/qjamEN).

A fancy toggle menu to edit quickly posts on websites.